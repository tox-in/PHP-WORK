<?php
$servername='localhost';
$username='root';
$dbname='student_db';
$password='';


$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "connection not succesful";
}else{
    echo "connected successfully.*.*.*.";
}
//in hashing password we can use:*MD5:message digest 5,**sha1:secure hash algorith1
?>