<?php
include('connection.php');

$id  = mysqli_real_escape_string($conn, $_GET["id"]);

$sqlDelete = "DELETE FROM contacts WHERE id='$id'";

if(mysqli_query($conn,$sqlDelete)){
    $sqlResetId = "ALTER TABLE contacts AUTO_INCREMENT = 1";
    mysqli_query($conn, $sqlResetId);
    $sqlMaxId = "SELECT MAX(id) FROM contacts";
    $result = mysqli_query($conn, $sqlMaxId);
     $maxId = mysqli_fetch_array($result)[0];
    $sqlUpdateId = "SET @count = 0";
    mysqli_query($conn, $sqlUpdateId);
    $sqlUpdateId = "UPDATE contacts SET id = @count:= @count + 1";
    mysqli_query($conn, $sqlUpdateId);
    session_start();
    
    $_SESSION["delete"] = "Contact Deleted Successfully!";
    header("Location:index.php");
}else{
    die("Something went wrong");
}
?>
